const bens_co_num = make_from_mag_ang_rectangular(	  
                        3.0, 0.7);

imag_part_rectangular(contents(bens_co_num));
