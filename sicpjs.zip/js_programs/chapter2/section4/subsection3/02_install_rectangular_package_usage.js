// chapter=3 
install_rectangular_package();
