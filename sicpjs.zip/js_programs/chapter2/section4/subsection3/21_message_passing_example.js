const my_complex_number = 
    make_from_real_imag(1.0, 4.5);

const result = 
    add_complex(my_complex_number,
                my_complex_number);

imag_part(result);
