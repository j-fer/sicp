list("a", "b");

// expected: [ 'a', [ 'b', null ] ]
