number_equal(3, 3);
