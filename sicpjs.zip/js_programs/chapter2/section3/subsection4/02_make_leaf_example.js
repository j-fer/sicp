const my_leaf = make_leaf("A", 8);

weight_leaf(my_leaf);
