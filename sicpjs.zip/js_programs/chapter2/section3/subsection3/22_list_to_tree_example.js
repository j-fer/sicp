head(tail(list_to_tree(list(10, 20, 30))));
