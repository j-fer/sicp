is_element_of_set(20, 
    make_tree(10,
        null,
        make_tree(30,
            make_tree(20, null, null),
            null)));
