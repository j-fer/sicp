const x = pair(1, 2);
head(x);
