const one_half = make_segment(make_point(0, 0), 
                              make_point(1, 1));
mid_point_segment(one_half);
