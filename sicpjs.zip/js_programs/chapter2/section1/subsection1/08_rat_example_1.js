numer(make_rat(2, 3));
