print_interval(div_interval(make_interval(1, 2), 
                            make_interval(3, 5)));
