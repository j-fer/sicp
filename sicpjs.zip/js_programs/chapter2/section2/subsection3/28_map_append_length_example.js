tail(map(math_sqrt, list(1, 2, 3, 4)));
