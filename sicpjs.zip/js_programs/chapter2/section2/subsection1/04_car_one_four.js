const one_through_four = list(1, 2, 3, 4);
head(one_through_four);

// expected: 1
