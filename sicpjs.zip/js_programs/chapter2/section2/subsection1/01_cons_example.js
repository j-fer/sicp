pair(1, 
     pair(2, 
          pair(3, 
               pair(4, null))));
