const odds = list(1, 3, 5, 7);

length(odds);
