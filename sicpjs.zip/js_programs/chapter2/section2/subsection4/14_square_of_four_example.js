function identity(x) {
    return x;
}
show(square_of_four(turn_upside_down, identity, 
                    quarter_turn_right, quarter_turn_left)
     (heart)
    );
