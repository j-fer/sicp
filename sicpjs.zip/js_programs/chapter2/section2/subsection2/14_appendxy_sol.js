const x = list(1, 2, 3);

const y = list(4, 5, 6);
append(x, y)
// result: [1, [2, [3, [4, [5, [6, null]]]]]]
